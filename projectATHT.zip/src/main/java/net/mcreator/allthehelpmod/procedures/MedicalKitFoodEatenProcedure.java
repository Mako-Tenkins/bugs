package net.mcreator.allthehelpmod.procedures;

import net.mcreator.allthehelpmod.AllTheHelpModModElements;

import java.util.Map;

@AllTheHelpModModElements.ModElement.Tag
public class MedicalKitFoodEatenProcedure extends AllTheHelpModModElements.ModElement {
	public MedicalKitFoodEatenProcedure(AllTheHelpModModElements instance) {
		super(instance, 11);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				System.err.println("Failed to load dependency entity for procedure MedicalKitFoodEaten!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).setHealth((float) 0);
	}
}
