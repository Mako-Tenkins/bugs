package net.mcreator.allthehelpmod.procedures;

import net.mcreator.allthehelpmod.AllTheHelpModModElements;

import java.util.Random;
import java.util.Map;

@AllTheHelpModModElements.ModElement.Tag
public class FertiliseMachineBlockDestroyedWithToolProcedure extends AllTheHelpModModElements.ModElement {
	public FertiliseMachineBlockDestroyedWithToolProcedure(AllTheHelpModModElements instance) {
		super(instance, 6);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				System.err.println("Failed to load dependency itemstack for procedure FertiliseMachineBlockDestroyedWithTool!");
			return;
		}
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		double b = 0;
		boolean f = false;
		{
			ItemStack _ist = (itemstack);
			if (_ist.attemptDamageItem((int) (-1), new Random(), null)) {
				_ist.shrink(1);
				_ist.setDamage(0);
			}
		}
	}
}
