package net.mcreator.allthehelpmod.procedures;

import net.mcreator.allthehelpmod.item.FertiliserItem;
import net.mcreator.allthehelpmod.AllTheHelpModModElements;

import java.util.Map;

@AllTheHelpModModElements.ModElement.Tag
public class FertiliseMachineRightClickedInAirProcedure extends AllTheHelpModModElements.ModElement {
	public FertiliseMachineRightClickedInAirProcedure(AllTheHelpModModElements instance) {
		super(instance, 5);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				System.err.println("Failed to load dependency entity for procedure FertiliseMachineRightClickedInAir!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				System.err.println("Failed to load dependency itemstack for procedure FertiliseMachineRightClickedInAir!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				System.err.println("Failed to load dependency x for procedure FertiliseMachineRightClickedInAir!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				System.err.println("Failed to load dependency y for procedure FertiliseMachineRightClickedInAir!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				System.err.println("Failed to load dependency z for procedure FertiliseMachineRightClickedInAir!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				System.err.println("Failed to load dependency world for procedure FertiliseMachineRightClickedInAir!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		double i = 0;
		double j = 0;
		if (((((itemstack)).getDamage()) != 4)) {
			i = (double) (-3);
			for (int index0 = 0; index0 < (int) (5); index0++) {
				i = (double) ((i) + 1);
				j = (double) (-4);
				for (int index1 = 0; index1 < (int) (5); index1++) {
					j = (double) ((j) + 1);
					if (BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL), world.getWorld(),
							new BlockPos((int) (x + (i)), (int) (y + 0), (int) (z + (j))))
							|| BoneMealItem.growSeagrass(new ItemStack(Items.BONE_MEAL), world.getWorld(),
									new BlockPos((int) (x + (i)), (int) (y + 0), (int) (z + (j))), (Direction) null)) {
						if (!world.getWorld().isRemote)
							world.getWorld().playEvent(2005, new BlockPos((int) (x + (i)), (int) (y + 0), (int) (z + (j))), 0);
					}
					if (BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL), world.getWorld(),
							new BlockPos((int) (x + (i)), (int) (y + 1), (int) (z + (j))))
							|| BoneMealItem.growSeagrass(new ItemStack(Items.BONE_MEAL), world.getWorld(),
									new BlockPos((int) (x + (i)), (int) (y + 1), (int) (z + (j))), (Direction) null)) {
						if (!world.getWorld().isRemote)
							world.getWorld().playEvent(2005, new BlockPos((int) (x + (i)), (int) (y + 1), (int) (z + (j))), 0);
					}
					if (BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL), world.getWorld(),
							new BlockPos((int) (x + (i)), (int) (y - 1), (int) (z + (j))))
							|| BoneMealItem.growSeagrass(new ItemStack(Items.BONE_MEAL), world.getWorld(),
									new BlockPos((int) (x + (i)), (int) (y - 1), (int) (z + (j))), (Direction) null)) {
						if (!world.getWorld().isRemote)
							world.getWorld().playEvent(2005, new BlockPos((int) (x + (i)), (int) (y - 1), (int) (z + (j))), 0);
					}
					if (BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL), world.getWorld(),
							new BlockPos((int) (x + (i)), (int) (y - 2), (int) (z + (j))))
							|| BoneMealItem.growSeagrass(new ItemStack(Items.BONE_MEAL), world.getWorld(),
									new BlockPos((int) (x + (i)), (int) (y - 2), (int) (z + (j))), (Direction) null)) {
						if (!world.getWorld().isRemote)
							world.getWorld().playEvent(2005, new BlockPos((int) (x + (i)), (int) (y - 2), (int) (z + (j))), 0);
					}
				}
			}
			((itemstack)).setDamage((int) ((((itemstack)).getDamage()) + 1));
		}
		if (((((itemstack)).getDamage()) == 4)) {
			if (((entity instanceof PlayerEntity)
					? ((PlayerEntity) entity).inventory.hasItemStack(new ItemStack(FertiliserItem.block, (int) (1)))
					: false)) {
				if (entity instanceof PlayerEntity) {
					ItemStack _stktoremove = new ItemStack(FertiliserItem.block, (int) (1));
					((PlayerEntity) entity).inventory.clearMatchingItems(p -> _stktoremove.getItem() == p.getItem(), (int) 1);
				}
				((itemstack)).setDamage((int) 0);
			}
		}
	}
}
