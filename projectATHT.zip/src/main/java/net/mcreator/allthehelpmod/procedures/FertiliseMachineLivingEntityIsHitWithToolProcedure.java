package net.mcreator.allthehelpmod.procedures;

import net.mcreator.allthehelpmod.AllTheHelpModModElements;

import java.util.Random;
import java.util.Map;

@AllTheHelpModModElements.ModElement.Tag
public class FertiliseMachineLivingEntityIsHitWithToolProcedure extends AllTheHelpModModElements.ModElement {
	public FertiliseMachineLivingEntityIsHitWithToolProcedure(AllTheHelpModModElements instance) {
		super(instance, 7);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				System.err.println("Failed to load dependency itemstack for procedure FertiliseMachineLivingEntityIsHitWithTool!");
			return;
		}
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		{
			ItemStack _ist = (itemstack);
			if (_ist.attemptDamageItem((int) (-2), new Random(), null)) {
				_ist.shrink(1);
				_ist.setDamage(0);
			}
		}
	}
}
