
package net.mcreator.allthehelpmod.enchantment;

import net.minecraftforge.registries.ObjectHolder;

import net.mcreator.allthehelpmod.AllTheHelpModModElements;

@AllTheHelpModModElements.ModElement.Tag
public class BoneExtractorEnchantment extends AllTheHelpModModElements.ModElement {
	@ObjectHolder("all_the_help_mod:bone_extractor")
	public static final Enchantment enchantment = null;
	public BoneExtractorEnchantment(AllTheHelpModModElements instance) {
		super(instance, 12);
	}

	@Override
	public void initElements() {
		elements.enchantments.add(() -> new CustomEnchantment(EquipmentSlotType.MAINHAND).setRegistryName("bone_extractor"));
	}
	public static class CustomEnchantment extends Enchantment {
		public CustomEnchantment(EquipmentSlotType... slots) {
			super(Enchantment.Rarity.RARE, EnchantmentType.WEAPON, slots);
		}

		@Override
		public int getMinLevel() {
			return 1;
		}

		@Override
		public int getMaxLevel() {
			return 5;
		}

		@Override
		public boolean isTreasureEnchantment() {
			return true;
		}

		@Override
		public boolean isCurse() {
			return false;
		}

		@Override
		public boolean isAllowedOnBooks() {
			return true;
		}
	}
}
