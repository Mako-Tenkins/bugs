
package net.mcreator.allthehelpmod.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.allthehelpmod.AllTheHelpModModElements;

@AllTheHelpModModElements.ModElement.Tag
public class AllTheHelpItemGroup extends AllTheHelpModModElements.ModElement {
	public AllTheHelpItemGroup(AllTheHelpModModElements instance) {
		super(instance, 3);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("taball_the_help") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(MedicalKitItem.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
